# Azizo Imports Website

A clean, responsive static website for Azizo Imports.

## Files
- `index.html` — main website
- `style.css` — styling and responsive layout
- `script.js` — small mobile-menu/year script
- `assets/azizo-logo.jpeg` — supplied Azizo Imports logo

## Contact
- Phone / WhatsApp: 0703 464 737
- Email: azizomickol@gmail.com

## GitHub Pages
1. Create a new GitHub repository.
2. Upload all files and the `assets` folder.
3. Make sure `index.html` is in the repository root.
4. In GitHub: Settings → Pages → Deploy from a branch → select `main` and `/ (root)`.
5. Save and wait for GitHub Pages to publish.

The WhatsApp buttons use the Kenyan international format `254703464737`.
